"""Terminal menu for SecureAuth."""
from getpass import getpass

import auth
import db


def main():
    db.init_db()
    while True:
        print("\n=== SecureAuth ===")
        print("1. Register")
        print("2. Login")
        print("3. Exit")
        choice = input("Choose: ").strip()

        if choice == "1":
            username = input("Username: ")
            password = getpass("Password: ")
            confirm = getpass("Confirm password: ")
            if password != confirm:
                print("Passwords do not match.")
                continue
            print(auth.register(username, password)[1])
        elif choice == "2":
            username = input("Username: ")
            password = getpass("Password: ")
            print(auth.login(username, password)[1])
        elif choice == "3":
            print("Bye!")
            break
        else:
            print("Invalid choice.")


if __name__ == "__main__":
    main()
