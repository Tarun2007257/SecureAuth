"""Run with: python -m unittest -v"""
import os
import tempfile
import unittest

import auth
import db
import security


class SecureAuthTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        db.DB_PATH = self.path
        db.init_db()

    def tearDown(self):
        os.remove(self.path)

    def test_same_password_gives_different_hashes(self):
        a = security.hash_password("Abcd@1234")
        b = security.hash_password("Abcd@1234")
        self.assertNotEqual(a[1], b[1])  # different salts

    def test_weak_password_rejected(self):
        self.assertFalse(auth.register("tarun", "abc")[0])

    def test_register_and_login(self):
        self.assertTrue(auth.register("tarun", "Str0ng@Pass")[0])
        self.assertTrue(auth.login("tarun", "Str0ng@Pass")[0])
        self.assertFalse(auth.login("tarun", "wrong")[0])

    def test_duplicate_username(self):
        auth.register("tarun", "Str0ng@Pass")
        self.assertFalse(auth.register("tarun", "Str0ng@Pass")[0])

    def test_lockout_after_three_failures(self):
        auth.register("tarun", "Str0ng@Pass")
        for _ in range(3):
            auth.login("tarun", "bad")
        ok, msg = auth.login("tarun", "Str0ng@Pass")
        self.assertFalse(ok)
        self.assertIn("locked", msg)

    def test_sql_injection_attempt_fails(self):
        auth.register("tarun", "Str0ng@Pass")
        self.assertFalse(auth.login("' OR '1'='1", "x")[0])


if __name__ == "__main__":
    unittest.main()
