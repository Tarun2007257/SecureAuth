"""Registration and login logic with account lockout."""
import re
import sqlite3
import time
from contextlib import closing

import db
import security

MAX_ATTEMPTS = 3
LOCK_SECONDS = 30
GENERIC_ERROR = "Invalid username or password."  # same message either way (no user enumeration)


def register(username, password):
    username = username.strip()
    if not re.fullmatch(r"[A-Za-z0-9_]{3,20}", username):
        return False, "Username must be 3-20 characters: letters, digits, underscore."
    problems = security.check_strength(password)
    if problems:
        return False, "Weak password. Needs: " + ", ".join(problems) + "."

    salt, pw_hash, iterations = security.hash_password(password)
    try:
        with closing(db.get_connection()) as conn, conn:
            conn.execute(
                "INSERT INTO users (username, salt, password_hash, iterations, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (username, salt, pw_hash, iterations, time.time()),
            )
    except sqlite3.IntegrityError:
        return False, "Username already taken."
    return True, "Registration successful."


def login(username, password):
    username = username.strip()
    with closing(db.get_connection()) as conn:
        row = conn.execute(
            "SELECT salt, password_hash, iterations, failed_attempts, locked_until "
            "FROM users WHERE username = ?",
            (username,),
        ).fetchone()

        if row is None:
            security.hash_password(password)  # dummy work so timing doesn't reveal valid usernames
            return False, GENERIC_ERROR

        salt, pw_hash, iterations, failed, locked_until = row
        now = time.time()
        if locked_until > now:
            return False, f"Account locked. Try again in {int(locked_until - now) + 1}s."

        if security.verify_password(password, salt, pw_hash, iterations):
            conn.execute(
                "UPDATE users SET failed_attempts = 0, locked_until = 0 WHERE username = ?",
                (username,),
            )
            conn.commit()
            return True, "Login successful."

        failed += 1
        lock_until = 0
        if failed >= MAX_ATTEMPTS:
            lock_until, failed = now + LOCK_SECONDS, 0
        conn.execute(
            "UPDATE users SET failed_attempts = ?, locked_until = ? WHERE username = ?",
            (failed, lock_until, username),
        )
        conn.commit()
        return False, GENERIC_ERROR
