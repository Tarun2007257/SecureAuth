"""SQLite setup. All queries elsewhere use ? placeholders (prevents SQL injection)."""
import sqlite3
from contextlib import closing

DB_PATH = "users.db"


def get_connection():
    return sqlite3.connect(DB_PATH)


def init_db():
    with closing(get_connection()) as conn, conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                username        TEXT NOT NULL UNIQUE,
                salt            TEXT NOT NULL,
                password_hash   TEXT NOT NULL,
                iterations      INTEGER NOT NULL,
                failed_attempts INTEGER NOT NULL DEFAULT 0,
                locked_until    REAL NOT NULL DEFAULT 0,
                created_at      REAL NOT NULL
            )
            """
        )
