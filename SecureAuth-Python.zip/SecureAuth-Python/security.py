"""Password hashing and strength checking (standard library only)."""
import hashlib
import hmac
import os
import re

ITERATIONS = 310_000  # PBKDF2 work factor; higher = slower for attackers


def hash_password(password, salt=None, iterations=ITERATIONS):
    """Return (salt_hex, hash_hex, iterations) using salted PBKDF2-HMAC-SHA256."""
    if salt is None:
        salt = os.urandom(16)  # unique random salt per user
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return salt.hex(), digest.hex(), iterations


def verify_password(password, salt_hex, hash_hex, iterations):
    """Re-hash the attempt with the stored salt and compare in constant time."""
    _, new_hash, _ = hash_password(password, bytes.fromhex(salt_hex), iterations)
    return hmac.compare_digest(new_hash, hash_hex)


def check_strength(password):
    """Return a list of problems. Empty list means the password is acceptable."""
    problems = []
    if len(password) < 8:
        problems.append("at least 8 characters")
    if not re.search(r"[A-Z]", password):
        problems.append("one uppercase letter")
    if not re.search(r"[a-z]", password):
        problems.append("one lowercase letter")
    if not re.search(r"\d", password):
        problems.append("one digit")
    if not re.search(r"[^A-Za-z0-9]", password):
        problems.append("one special character")
    if password.lower() in {"password", "password1", "12345678", "qwerty123", "admin123"}:
        problems.append("not a commonly used password")
    return problems
